app.controller("RentabilidadeController", function($scope, $http){

	$http.get("https://private-anon-91c09a86bf-ricocomvc.apiary-mock.com/indexes").then(response => {
		$scope.indices = response.data;
	}, err => {
		console.log(err);
	});

	getIpca();

	function getIpca(){
		$http.get("https://private-anon-91c09a86bf-ricocomvc.apiary-mock.com/treasury").then(response => {
			$scope.treasuries = response.data;

			var treasuriesComTaxa = [];

			response.data.forEach(treasury => {

				switch(treasury.index.name){
					case "SELIC":
						treasury.currentInterestRate = (Number(treasury.currentInterestRate) + Number($scope.indices.SELIC));
						break;

					case "IPCA":
						treasury.currentInterestRate = (Number(treasury.currentInterestRate) + Number($scope.indices.IPCA));
						break;
				}

				treasuriesComTaxa.push(treasury);
			});

			$scope.treasuriesComTaxa = treasuriesComTaxa;

		}, err => {
			console.log(err);
		});
	}

	$scope.calcRentabilidade = function(tempoInvestimento, valorInvestido) {

		getIpca();

		var rentabilidades = [];

		console.log($scope.treasuriesComTaxa);

		$scope.treasuriesComTaxa.forEach(t => {
			console.log(t.currentInterestRate);

			var copy = t;

			var anos = tempoInvestimento / 360;
			copy.currentInterestRate = anos * (valorInvestido * copy.currentInterestRate) + valorInvestido;
			rentabilidades.push(copy);

		});

		rentabilidades = rentabilidades.filter(r => {
			return r.minimumValue <= valorInvestido;
		})
        
    	$scope.rentabilidades = rentabilidades.sort(function(a, b){
			return b.currentInterestRate - a.currentInterestRate;
		});

    	var cont = 0;
		$scope.labels = ['1', '2', '3', '4', '5'];
		$scope.legendas = $scope.rentabilidades.slice(0, 5).map(r => {
			return ++cont + " - " + r.name;
		});

  		$scope.data = $scope.rentabilidades.slice(0, 5).map(r => {
			return r.currentInterestRate;
		});

		$scope.tempoInvestimento = "";
		$scope.valorInvestido = "";
		$scope.visible = true;
    }

});